import sys
import os
import cv2
from PyQt5.QtWidgets import QApplication, QMainWindow, QGraphicsScene, QGraphicsPixmapItem, \
    QMessageBox, QFileDialog
from GUI import Ui_MainWindow2  # 导入 GUI.py 中的 Ui_MainWindow 界面类
from FirstWin import Ui_MainWindow1
from PyQt5.QtGui import QPixmap, QImage
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageTk
# from tkinter import messagebox

class MyMainWindow(QMainWindow, Ui_MainWindow2):  # 继承 QMainWindow 类和 Ui_MainWindow 界面类
    def __init__(self, parent=None):
        super(MyMainWindow, self).__init__(parent)  # 初始化父类
        self.setupUi(self)  # 继承 Ui_MainWindow 界面类
        self.img_temp = list()
        self.img_temp.append(cv2.imread(r'.\templete\1201dlsc.jpg'))
        self.img_temp.append(cv2.imread(r'.\templete\jcqx.png'))
        self.img_temp.append(cv2.imread(r'.\templete\wbddcxs.jpg'))
        self.img_temp.append(cv2.imread(r'.\templete\zjyhh.png'))
        self.checking_img = None
        self.checking_img_backup = None
        self.imgName = None
        self.fault_str_cn = ['电缆受潮','尖刺缺陷','外半导电层损伤','主绝缘划痕']
        self.fault_str_en = ['DLSC', 'JCQX', 'WBDDXS', 'ZJYHH']
        self.fault_code = None
        self.pushButton_2.setEnabled(False)
        self.pushButton_4.setEnabled(False)


    def open_image(self):
        self.imgName, imgType = QFileDialog.getOpenFileName(self, "打开待检测的局放图像", ".\\test_img", "*.jpg;;*.png;;*.bmp")
        if self.imgName == "":
            pass
        else:
            self.checking_img = cv2.imread(self.imgName)
            self.checking_img_backup = self.checking_img.copy()
            self.img_show(1, self.imgName)
            self.pushButton_2.setEnabled(True)
        print(self.imgName)


    def calculate(self, image1, image2):
        # 灰度直方图算法
        # 计算单通道的直方图的相似值
        hist1 = cv2.calcHist([image1], [0], None, [256], [0.0, 255.0])
        hist2 = cv2.calcHist([image2], [0], None, [256], [0.0, 255.0])
        # 计算直方图的重合度
        degree = 0
        for i in range(len(hist1)):
            if hist1[i] != hist2[i]:
                degree = degree + \
                         (1 - abs(hist1[i] - hist2[i]) / max(hist1[i], hist2[i]))
            else:
                degree = degree + 1
        degree = degree / len(hist1)
        return degree

    def cmpHash(self, hash1, hash2):
        # Hash值对比
        # 算法中1和0顺序组合起来的即是图片的指纹hash。顺序不固定，但是比较的时候必须是相同的顺序。
        # 对比两幅图的指纹，计算汉明距离，即两个64位的hash值有多少是不一样的，不同的位数越小，图片越相似
        # 汉明距离：一组二进制数据变成另一组数据所需要的步骤，可以衡量两图的差异，汉明距离越小，则相似度越高。汉明距离为0，即两张图片完全一样
        n = 0
        # hash长度不同则返回-1代表传参出错
        if len(hash1) != len(hash2):
            return -1
        # 遍历判断
        for i in range(len(hash1)):
            # 不相等则n计数+1，n最终为相似度
            if hash1[i] != hash2[i]:
                n = n + 1
        return n

    def classify_hist_with_split(self, image1, image2, size=(256, 256)):
        # RGB每个通道的直方图相似度
        # 将图像resize后，分离为RGB三个通道，再计算每个通道的相似值
        image1 = cv2.resize(image1, size)
        image2 = cv2.resize(image2, size)
        sub_image1 = cv2.split(image1)
        sub_image2 = cv2.split(image2)
        sub_data = 0
        for im1, im2 in zip(sub_image1, sub_image2):
            sub_data += self.calculate(im1, im2)
        sub_data = sub_data / 3
        return sub_data

    def start_checking(self):
        # 直方图相似度检测
        score_2 = list()
        for i in range(len(self.img_temp)):
            score_2.append(self.classify_hist_with_split(self.img_temp[i], self.checking_img))
            # score_2.append(self.calculate(self.img_temp[i], self.checking_img))
            # hash1 = self.aHash(self.img_temp[i])
            # hash2 = self.aHash(self.checking_img)
            # score_2.append(self.cmpHash(hash1, hash2))

        # print(self.score_1)
        print(score_2)
        self.fault_code = np.argmax(score_2)
        print(self.fault_str_cn[self.fault_code])
        # self.fault_code = fault_feature


        # self.textBrowser.clear()
        # self.textBrowser.append('局放图像：'+self.imgName)
        # self.textBrowser.append('与电缆受潮特征相似度：' + str(self.score_2[0][0]*100)+'%')
        # self.textBrowser.append('与尖刺缺陷特征相似度：' + str(self.score_2[1][0] * 100) + '%')
        # self.textBrowser.append('与外半导电层损伤特征相似度：' + str(self.score_2[2][0] * 100) + '%')
        # self.textBrowser.append('与主绝缘划痕特征相似度：' + str(self.score_2[3][0] * 100) + '%')

        if self.fault_code == 0:
            print(self.fault_code)
            checked_result_img = self.show_message(self.checking_img.copy(), self.fault_str_cn[self.fault_code], (255, 0, 0))
        elif self.fault_code == 1:
            checked_result_img = self.show_message(self.checking_img.copy(), self.fault_str_cn[self.fault_code], (255, 0, 0))
        elif self.fault_code == 2:
            checked_result_img = self.show_message(self.checking_img.copy(), self.fault_str_cn[self.fault_code], (255, 0, 0))
        else:
            checked_result_img = self.show_message(self.checking_img.copy(), self.fault_str_cn[self.fault_code], (255, 0, 0))
        cv2.imwrite(r'.\work\resulted_img.jpg', checked_result_img)
        self.img_show(2, self.imgName)
        self.pushButton_4.setEnabled(True)

    def load_template(self):
        imgName, imgType = QFileDialog.getOpenFileName(self, "打开局放图像模板", ".\\模板",
                                                       "*.jpg;;*.bmp;;*.png")
        if imgName == "":
            pass
        else:
            self.img_show(0, imgName)

    def aHash(self, img):
        # 均值哈希算法
        # 缩放为8*8
        img = cv2.resize(img, (8, 8))
        # 转换为灰度图
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        # s为像素和初值为0，hash_str为hash值初值为''
        s = 0
        hash_str = ''
        # 遍历累加求像素和
        for i in range(8):
            for j in range(8):
                s = s + gray[i, j]
        # 求平均灰度
        avg = s / 64
        # 灰度大于平均值为1相反为0生成图片的hash值
        for i in range(8):
            for j in range(8):
                if gray[i, j] > avg:
                    hash_str = hash_str + '1'
                else:
                    hash_str = hash_str + '0'
        return hash_str

    def dHash(self, img):
        # 差值哈希算法
        # 缩放8*8
        img = cv2.resize(img, (9, 8))
        # 转换灰度图
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        hash_str = ''
        # 每行前一个像素大于后一个像素为1，相反为0，生成哈希
        for i in range(8):
            for j in range(8):
                if gray[i, j] > gray[i, j + 1]:
                    hash_str = hash_str + '1'
                else:
                    hash_str = hash_str + '0'
        return hash_str

    def pHash(self, img):
        # 感知哈希算法
        # 缩放32*32
        img = cv2.resize(img, (32, 32))  # , interpolation=cv2.INTER_CUBIC

        # 转换为灰度图
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        # 将灰度图转为浮点型，再进行dct变换
        dct = cv2.dct(np.float32(gray))
        # opencv实现的掩码操作
        dct_roi = dct[0:8, 0:8]

        hash = []
        avreage = np.mean(dct_roi)
        for i in range(dct_roi.shape[0]):
            for j in range(dct_roi.shape[1]):
                if dct_roi[i, j] > avreage:
                    hash.append(1)
                else:
                    hash.append(0)
        return hash

    def img_show(self, flag, img_name):
        disp_img = QPixmap()
        if flag == 0:
            disp_img.load(img_name)
            item = QGraphicsPixmapItem(disp_img)  # 创建像素图元
            scene = QGraphicsScene()  # 创建场景
            scene.clear()
            scene.addItem(item)
            self.graphicsView.setScene(scene)
            self.graphicsView.fitInView(item)
        elif flag == 1:
            disp_img.load(img_name)
            item = QGraphicsPixmapItem(disp_img)  # 创建像素图元
            scene = QGraphicsScene()  # 创建场景
            scene.clear()
            scene.addItem(item)
            self.graphicsView_2.setScene(scene)
            self.graphicsView_2.fitInView(item)
        elif flag == 2:
            disp_img.load(r'.\work\resulted_img.jpg')
            item = QGraphicsPixmapItem(disp_img)  # 创建像素图元
            scene = QGraphicsScene()  # 创建场景
            scene.clear()
            scene.addItem(item)
            self.graphicsView_3.setScene(scene)
            self.graphicsView_3.fitInView(item)

    # 图片显示文字
    def show_message(self, img, str, color):
        pil_img1 = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        [h, w] = pil_img1.shape[:2]
        pilimg1 = Image.fromarray(pil_img1)  # 将数组类型转成图片格式
        draw = ImageDraw.Draw(pilimg1)  # 在PIL图片上打印汉字
        font = ImageFont.truetype("simhei.ttf", 25, encoding="utf-8")
        draw.text((70, h-180), str, color, font=font)
        img_1 = cv2.cvtColor(np.array(pilimg1), cv2.COLOR_RGB2BGR)  # 将图片转成cv2.imshow()可以显示的数组格式

        return img_1

    def save_fault(self):
        for i in range(len(self.imgName)-1):
            if self.imgName[-(i+1)] == '/':
                break
        save_name = self.imgName[-i::]
        mark_name = self.fault_str_en[self.fault_code]
        ifname = '.\\templete\\'+ mark_name +'-' + save_name
        # print(ipath)
        cv2.imwrite(ifname, self.checking_img.copy())
        if os.path.exists(ifname):
            reply = QMessageBox.question(self, '保存文件', self.fault_str_cn[self.fault_code]+'缺陷特征保存成功！文件名为：'+mark_name +'-' + save_name,
                                         QMessageBox.Yes , QMessageBox.Yes)
            if reply == QMessageBox.Yes:
                pass
        else:
            reply = QMessageBox.question(self, '保存文件', self.fault_str_cn[self.fault_code] + '缺陷特征保存失败，请重试！',
                                         QMessageBox.Yes, QMessageBox.Yes)
            if reply == QMessageBox.Yes:
                pass


class FirstWindow(QMainWindow, Ui_MainWindow1):  # 继承 QMainWindow 类和 Ui_MainWindow 界面类
    def __init__(self, parent=None):
        super(FirstWindow, self).__init__(parent)  # 初始化父类
        self.setupUi(self)  # 继承 Ui_MainWindow 界面类

    def click(self):
        myWin2.show()  # 在桌面显示控件 myWin
        myWin1.close()


if __name__ == '__main__':  #
    app = QApplication(sys.argv)  # 在 QApplication 方法中使用，创建应用程序对象
    myWin1 = FirstWindow()  # 实例化 MyMainWindow 类，创建主窗口
    myWin2 = MyMainWindow()
    myWin1.show()
    sys.exit(app.exec_())  # 结束进程，退出程序
